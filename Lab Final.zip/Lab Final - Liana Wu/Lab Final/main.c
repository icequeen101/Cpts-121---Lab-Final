/* 
	FOR YOUR CONVIENCE :)
	Programmer: Liana Wu
	Assignment: LAST LAB EVER
	Date: 12/4/2019
	Description: YESSSSSS, I'M DONE. 
	Sidethought: WHAT'S WITH THAT STUPID ALPHABET ORGANIZATION PART!!!
	Comments to TA: THANKS KATRINA, BEST TA EVER - WILL MISS YOU!!! :D
*/


#include "header.h"

int main(void) {

	/* Variables */
	char plan = '\0';
	int customer_num = 0,
		talk_minutes = 0, data_MB = 0, garbage = 0;
	double charges = 0.0;
	Profile company_profile[100] = { {'\0'}, '\0', 0, 0, 0.0 };

	/* File Variables */
	FILE* infile = NULL, * outfile = NULL;
	infile = fopen("customers.txt", "r");
	outfile = fopen("charges.txt", "w");

	/* Read File & Store in Profile */
	while (!feof(infile)) {
		fgets(company_profile[customer_num].name, 100, infile);
		fscanf(infile, "%c", &plan);
		fscanf(infile, "%d", &talk_minutes);
		fscanf(infile, "%d", &data_MB);
		fscanf(infile, "%d", &garbage);

		company_profile[customer_num].plan = plan;
		company_profile[customer_num].talk_minutes = talk_minutes;
		company_profile[customer_num].data_MB = data_MB;

		/* TEST */
		/*printf("Customer Name: %s", company_profile[customer_num].name);
		printf("Plan: %c\n", company_profile[customer_num].plan);
		printf("Talk Minutes: %d\n", company_profile[customer_num].talk_minutes);
		printf("Data: %d\n", company_profile[customer_num].data_MB);
		printf("\n");*/

		customer_num++;
	}



	/* Sorting Profile Reverse Alphabetically */
	char temp_name[20] = { '\0' }, temp_plan = '\0';
	int largest_string = 0,
		temp_talk_minutes = 0, temp_data_MB = 0;

	for (int i = 0; i < customer_num; i++) {
		int num = strcmp(company_profile[i].name, company_profile[i + 1].name);

		if (num == -1) {
			for (int j = 0; j < 20; j++) {

				temp_name[j] = company_profile[i].name[j];
				company_profile[i].name[j] = company_profile[i + 1].name[j];
				company_profile[i + 1].name[j] = temp_name[j];
			}

			temp_plan = company_profile[i].plan;
			company_profile[i].plan = company_profile[i + 1].plan;
			company_profile[i + 1].plan = temp_plan;

			temp_talk_minutes = company_profile[i].talk_minutes;
			company_profile[i].talk_minutes = company_profile[i + 1].talk_minutes;
			company_profile[i + 1].talk_minutes = temp_talk_minutes;

			temp_data_MB = company_profile[i].data_MB;
			company_profile[i].data_MB = company_profile[i + 1].data_MB;
			company_profile[i + 1].data_MB = temp_data_MB;
		}
	}

	/* Calculate Charges */
	int overtime_MB,
		overtime_minutes = 0;

	for (int i = 0; i < customer_num; i++) {
		if (company_profile[i].plan == 'A') {
			if (company_profile[i].talk_minutes > 1000) {
				overtime_minutes = company_profile[i].talk_minutes - 1000;
				charges = overtime_minutes * 0.50;
				company_profile[i].charges += charges;
			}

			if (company_profile[i].data_MB > 10000) {
				overtime_MB = company_profile[i].data_MB - 10000;
				charges = overtime_MB * 0.25;
				company_profile[i].charges += charges;
			}
			company_profile[i].charges += 60;
		}

		if (company_profile[i].plan == 'B') {
			if (company_profile[i].talk_minutes > 2000) {
				overtime_minutes = company_profile[i].talk_minutes - 2000;
				charges = overtime_minutes * 0.40;
				company_profile[i].charges += charges;
			}

			if (company_profile[i].data_MB > 20000) {
				overtime_MB = company_profile[i].data_MB - 20000;
				charges = overtime_MB * 0.15;
				company_profile[i].charges += charges;
			}
			company_profile[i].charges += 85;
		}
	}

	/* TEST */
	/*for (int i = 0; i < customer_num; i++) {
		printf("Customer Name: %s", company_profile[i].name);
		printf("Plan: %c\n", company_profile[i].plan);
		printf("Talk Minutes: %d\n", company_profile[i].talk_minutes);
		printf("Data: %d\n", company_profile[i].data_MB);
		printf("Charges: %lf\n", company_profile[i].charges);
		printf("\n");
	}*/

	/* Calculate Total Sum, Average, Max & Min Charges */
	double total_sum = 0.0, average = 0.0,
		max_charge = company_profile[0].charges,
		min_charge = company_profile[0].charges;

	for (int i = 0; i < customer_num; i++) {
		total_sum += company_profile[i].charges;

		if (max_charge < company_profile[i].charges) {
			max_charge = company_profile[i].charges;
		}

		if (min_charge > company_profile[i].charges) {
			min_charge = company_profile[i].charges;
		}
	}

	average = total_sum / customer_num;

	/* TEST */
	/*printf("Total Sum: %lf\n", total_sum);
	printf("Average: %lf\n", average);
	printf("Max: %lf\n", max_charge);
	printf("Min: %lf\n", min_charge);*/

	/* Write To File */
	fprintf(outfile, "Total Sum: $%.2lf\n", total_sum);
	fprintf(outfile, "Average: $%.2lf\n", average);
	fprintf(outfile, "Max: $%.2lf\n", max_charge);
	fprintf(outfile, "Min: $%.2lf\n", min_charge);

	/* Close Files */
	fclose(infile);
	fclose(outfile);

	return 0;
}