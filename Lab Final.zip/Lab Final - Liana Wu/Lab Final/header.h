#include < stdio.h>
#include <string.h>

typedef struct profile {
	char name[100];		// customer's name - last, first
	char plan;			// plan 'A' or 'B'
	int talk_minutes;	// number of minutes used for talking
	int data_MB;		// amount of data used in MB
	double charges;		// total charges for this customer - compute
} Profile;